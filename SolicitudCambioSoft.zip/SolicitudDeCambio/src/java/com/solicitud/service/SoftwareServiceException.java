/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.solicitud.service;

/**
 *
 * @author Michael Rodriguez
 */
public class SoftwareServiceException extends Exception{
    
    public SoftwareServiceException() {
    }

    public SoftwareServiceException(String message) {
        super(message);
    }

    public SoftwareServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public SoftwareServiceException(Throwable cause) {
        super(cause);
    }

    public SoftwareServiceException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
