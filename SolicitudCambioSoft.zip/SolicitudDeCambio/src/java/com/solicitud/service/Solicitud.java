/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.solicitud.service;

import com.software.CambioAprovado;
import com.software.Software;
import java.util.Date;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.xml.ws.BindingType;

/**
 *
 * @author Michael Rodriguez
 */
@WebService(serviceName = "SolicitudService")
@BindingType(javax.xml.ws.soap.SOAPBinding.SOAP12HTTP_BINDING)
public class Solicitud {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "softwareById")
    public Software softwareById(@WebParam(name = "id") int id) throws SoftwareServiceException {
        Software soft = CambioAprovado.getInstancia().getSoftwareById(id);
        return soft;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "addChange")
    public void addChange(@WebParam(name = "id") int id, @WebParam(name = "fecha") String fecha, @WebParam(name = "cambio") String cambio, @WebParam(name = "comment") String comment) throws SoftwareServiceException{
        CambioAprovado.getInstancia().addChange(id, fecha, cambio, comment);
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "verify")
    public Boolean verify(@WebParam(name = "id") int id) {
        return CambioAprovado.getInstancia().verificar(id);
    }
}
