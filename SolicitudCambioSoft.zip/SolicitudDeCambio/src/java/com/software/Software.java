/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.software;

import com.cambio.Cambio;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Michael Rodriguez
 */
public class Software {

    private int id_software;
    private String nombre;
    private List<Cambio> cambios = new ArrayList<>();
    private int cantidad;
    private boolean status;

    public Software() {
    }

    public Software(int id_software, String nombre) {
        this.id_software = id_software;
        this.nombre = nombre;
    }

    public Software(int id, String nombre, Cambio... cambio) {
        this(id, nombre);
        for (Cambio c : cambio) {
            getCambios().add(c);
        }
        cantidad = getCambios().size();
        if (cantidad <= 5) {
            setStatus(true);
        } else {
            setStatus(false);
        }
    }

    /**
     * @return the id_software
     */
    public int getId_software() {
        return id_software;
    }

    /**
     * @param id_software the id_software to set
     */
    public void setId_software(int id_software) {
        this.id_software = id_software;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the cambios
     */
    public List<Cambio> getCambios() {
        return cambios;
    }

    /**
     * @param cambios the cambios to set
     */
    public void setCambios(List<Cambio> cambios) {
        this.cambios = cambios;
    }

    /**
     * @return the cantidad
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * @param cantidad the cantidad to set
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    /**
     * @return the status
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(boolean status) {
        this.status = status;
    }

}
