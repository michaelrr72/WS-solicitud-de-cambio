/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.software;

import com.cambio.Cambio;
import com.software.Software;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Michael Rodriguez
 */
public class CambioAprovado {

    private static CambioAprovado instancia = new CambioAprovado();

    public static CambioAprovado getInstancia() {
        return instancia;
    }

    private List<Software> softs = new ArrayList<Software>();

    private CambioAprovado() {
        softs.add(new Software(1, "Geogebra", new Cambio(new Date(116, 10, 3)+""+"", "asd", "asd"), new Cambio(new Date(116, 10, 3)+"", "asd", "asd"), new Cambio(new Date(116, 10, 3)+"", "asd", "asd")));
        softs.add(new Software(2, "Wolfram Mathematica", new Cambio(new Date(116, 10, 3)+"", "asd", "asd"),new Cambio(new Date(116, 10, 3)+"", "asd", "asd"),new Cambio(new Date(116, 10, 3)+"", "asd", "asd"),new Cambio(new Date(116, 10, 3)+"", "asd", "asd"),new Cambio(new Date(116, 10, 3)+"", "asd", "asd")));
        softs.add(new Software(3, "World of Warcraft", new Cambio(new Date(116, 10, 3)+"", "asd", "asd")));
    }

    public List<Software> getSofts() {
        return softs;
    }

    public void setSofts(List<Software> softs) {
        this.softs = softs;
    }

    public List<Software> getListSoftwareById(int id) {
        List<Software> s = new ArrayList<>();
        for (Software soft : softs) {
            if (soft.getId_software() == id) {
                s.add(soft);
            }
        }
        return s;
    }

    public Software getSoftwareById(int id) {
        for (Software soft : softs) {
            if (soft.getId_software() == id) {
                return soft;
            }
        }

        return null;
    }

    public void addChange(int id, String fecha, String cambio, String comment) {
        Software s = getSoftwareById(id);
        if (s != null) {
            if (s.getCambios().size() < 5) {
                s.getCambios().add(new Cambio(fecha, cambio, comment));
            }
        }

    }
    
    public boolean verificar(int id) {
        Software s = getSoftwareById(id);
        if (s != null) {
            if (s.getCambios().size() < 5) {
                return true;
            }
        }
        return false;

    }
    

}
